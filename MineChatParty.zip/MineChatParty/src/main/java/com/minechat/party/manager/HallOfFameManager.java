package com.minechat.party.manager;

import com.minechat.party.MineChatParty;
import com.minechat.party.model.Party;
import com.minechat.party.model.PartyMember;
import com.minechat.party.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;

import static com.minechat.party.manager.MessageManager.ph;
import static com.minechat.party.manager.MessageManager.points;

/**
 * Runs the timed Hall of Fame events.
 * State lives in hallofframe.yml, finished events (winners + members) are appended to winners.yml.
 */
public final class HallOfFameManager {

    public enum EndReason {
        EXPIRED,
        MANUAL
    }

    private final MineChatParty plugin;
    private final PartyManager parties;
    private final MessageManager messages;

    private final File stateFile;
    private final File winnersFile;

    private int eventNumber;
    private boolean active;
    private long startedAt;
    private long endsAt;

    private BukkitTask task;

    public HallOfFameManager(MineChatParty plugin, PartyManager parties, MessageManager messages) {
        this.plugin = plugin;
        this.parties = parties;
        this.messages = messages;
        this.stateFile = new File(plugin.getDataFolder(), "hallofframe.yml");
        this.winnersFile = new File(plugin.getDataFolder(), "winners.yml");
    }

    // ---------------------------------------------------------------- lifecycle

    public void load() {
        boolean firstRun = !stateFile.exists();

        if (!firstRun) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(stateFile);
            eventNumber = yaml.getInt("event-number");
            active = yaml.getBoolean("active");
            startedAt = yaml.getLong("started-at");
            endsAt = yaml.getLong("ends-at");
        }

        if (firstRun) {
            if (plugin.getConfig().getBoolean("hall-of-fame.auto-start", true)) {
                start();
            } else {
                save();
            }
        } else if (active && System.currentTimeMillis() >= endsAt) {
            // The event ran out while the server was offline.
            end(EndReason.EXPIRED);
            if (plugin.getConfig().getBoolean("hall-of-fame.auto-restart", true)) {
                start();
            }
        }
    }

    public void startTimer() {
        // Check every 10 seconds.
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 200L, 200L);
    }

    public void stopTimer() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void tick() {
        if (active && System.currentTimeMillis() >= endsAt) {
            end(EndReason.EXPIRED);
            if (plugin.getConfig().getBoolean("hall-of-fame.auto-restart", true)) {
                start();
            }
        }
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("event-number", eventNumber);
        yaml.set("active", active);
        yaml.set("started-at", startedAt);
        yaml.set("ends-at", endsAt);
        try {
            yaml.save(stateFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save hallofframe.yml", e);
        }
    }

    // ---------------------------------------------------------------- start / end

    /** Starts a new event and resets all party points. Returns false if one is already running. */
    public boolean start() {
        if (active) {
            return false;
        }
        double days = plugin.getConfig().getDouble("hall-of-fame.duration-days", 7.0);
        long durationMillis = Math.max(60_000L, (long) (days * 86_400_000d));

        long now = System.currentTimeMillis();
        eventNumber++;
        active = true;
        startedAt = now;
        endsAt = now + durationMillis;

        parties.resetAllPoints();
        save();

        messages.broadcast("hof-started",
                ph("event", eventNumber),
                ph("time", TimeUtil.formatDuration(durationMillis)));
        return true;
    }

    /** Ends the running event, saves the winners and announces them. Returns false if none is running. */
    public boolean end(EndReason reason) {
        if (!active) {
            return false;
        }
        active = false;
        long endedAt = System.currentTimeMillis();

        int topCount = Math.max(1, plugin.getConfig().getInt("hall-of-fame.winners-top-count", 3));
        List<Party> board = getLeaderboard();
        List<Party> winners = new ArrayList<>(board.subList(0, Math.min(topCount, board.size())));

        saveWinners(winners, endedAt, reason);
        save();

        messages.broadcast("hof-ended", ph("event", eventNumber));
        if (winners.isEmpty()) {
            messages.broadcast("hof-ended-none");
        } else {
            for (int i = 0; i < winners.size(); i++) {
                Party party = winners.get(i);
                messages.broadcast("hof-ended-place",
                        ph("place", i + 1),
                        ph("party", party.getName()),
                        points("points", party.getPoints()));
            }
        }
        plugin.getLogger().info("Hall of Fame #" + eventNumber + " ended (" + reason + "). Winners saved to winners.yml.");
        return true;
    }

    private void saveWinners(List<Party> winners, long endedAt, EndReason reason) {
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(winnersFile);

        String base = "events." + eventNumber;
        yaml.set(base + ".started-at", Instant.ofEpochMilli(startedAt).toString());
        yaml.set(base + ".ended-at", Instant.ofEpochMilli(endedAt).toString());
        yaml.set(base + ".started-at-millis", startedAt);
        yaml.set(base + ".ended-at-millis", endedAt);
        yaml.set(base + ".end-reason", reason.name());

        for (int i = 0; i < winners.size(); i++) {
            Party party = winners.get(i);
            String placeBase = base + ".placements." + (i + 1);
            yaml.set(placeBase + ".party-name", party.getName());
            yaml.set(placeBase + ".party-id", party.getId().toString());
            yaml.set(placeBase + ".points", party.getPoints());
            // Flip this to true when you've handed out the rewards.
            yaml.set(placeBase + ".rewarded", false);

            for (PartyMember member : party.getMembers()) {
                String memberBase = placeBase + ".members." + member.getUuid();
                yaml.set(memberBase + ".name", member.getName());
                yaml.set(memberBase + ".role", member.getRole().name());
                yaml.set(memberBase + ".contribution", party.getContribution(member.getUuid()));
            }
        }

        try {
            yaml.save(winnersFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save winners.yml", e);
        }
    }

    // ---------------------------------------------------------------- points & standings

    /** Adds points to a party. Returns false (and does nothing) if no event is running. */
    public boolean addPoints(Party party, Player contributor, double amount) {
        if (!active || amount <= 0) {
            return false;
        }
        party.addPoints(contributor.getUniqueId(), amount);
        parties.save();
        return true;
    }

    /** Parties with at least 1 point, best first. */
    public List<Party> getLeaderboard() {
        return parties.getParties().stream()
                .filter(party -> party.getPoints() > 0)
                .sorted(Comparator.comparingDouble(Party::getPoints).reversed()
                        .thenComparing(Party::getName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    /** 1-based rank, or -1 if the party has no points. */
    public int getRank(Party party) {
        List<Party> board = getLeaderboard();
        for (int i = 0; i < board.size(); i++) {
            if (board.get(i).getId().equals(party.getId())) {
                return i + 1;
            }
        }
        return -1;
    }

    // ---------------------------------------------------------------- getters

    public boolean isActive() {
        return active;
    }

    public int getEventNumber() {
        return eventNumber;
    }

    public long getRemainingMillis() {
        return Math.max(0L, endsAt - System.currentTimeMillis());
    }
}
