package com.minechat.party;

import com.minechat.party.command.PartyCommand;
import com.minechat.party.listener.PartyListener;
import com.minechat.party.manager.HallOfFameManager;
import com.minechat.party.manager.ItemWorthManager;
import com.minechat.party.manager.MessageManager;
import com.minechat.party.manager.PartyManager;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class MineChatParty extends JavaPlugin {

    private PartyManager partyManager;
    private HallOfFameManager hallOfFameManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();

        MessageManager messages = new MessageManager(this);
        ItemWorthManager itemWorth = new ItemWorthManager(this);

        partyManager = new PartyManager(this);
        partyManager.load();

        hallOfFameManager = new HallOfFameManager(this, partyManager, messages);
        hallOfFameManager.load();
        hallOfFameManager.startTimer();

        PluginCommand command = getCommand("party");
        if (command == null) {
            getLogger().severe("Command 'party' is missing from plugin.yml!");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        PartyCommand executor = new PartyCommand(this, partyManager, hallOfFameManager, itemWorth, messages);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        getServer().getPluginManager().registerEvents(new PartyListener(partyManager), this);

        getLogger().info("MineChatParty enabled.");
    }

    @Override
    public void onDisable() {
        if (hallOfFameManager != null) {
            hallOfFameManager.stopTimer();
            hallOfFameManager.save();
        }
        if (partyManager != null) {
            partyManager.save();
        }
    }
}
