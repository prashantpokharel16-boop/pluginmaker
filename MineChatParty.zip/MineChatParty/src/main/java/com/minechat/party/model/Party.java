package com.minechat.party.model;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public final class Party {

    private final UUID id;
    private final String name;
    private final long createdAt;

    private final Map<UUID, PartyMember> members = new LinkedHashMap<>();
    private final Map<UUID, Double> contributions = new HashMap<>();
    private double points;

    public Party(UUID id, String name, long createdAt) {
        this.id = id;
        this.name = name;
        this.createdAt = createdAt;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    // ---- members ----

    public Collection<PartyMember> getMembers() {
        return Collections.unmodifiableCollection(members.values());
    }

    public int size() {
        return members.size();
    }

    public PartyMember getMember(UUID uuid) {
        return members.get(uuid);
    }

    public PartyMember getMemberByName(String name) {
        for (PartyMember member : members.values()) {
            if (member.getName().equalsIgnoreCase(name)) {
                return member;
            }
        }
        return null;
    }

    public PartyMember getLeader() {
        for (PartyMember member : members.values()) {
            if (member.getRole() == PartyRole.LEADER) {
                return member;
            }
        }
        return null;
    }

    /** Highest-ranked non-leader member (earliest joined wins ties), or null if there is none. */
    public PartyMember findSuccessor() {
        PartyMember best = null;
        for (PartyMember member : members.values()) {
            if (member.getRole() == PartyRole.LEADER) {
                continue;
            }
            if (best == null || member.getRole().ordinal() > best.getRole().ordinal()) {
                best = member;
            }
        }
        return best;
    }

    public void addMember(PartyMember member) {
        members.put(member.getUuid(), member);
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
    }

    // ---- points ----

    public double getPoints() {
        return points;
    }

    public void setPoints(double points) {
        this.points = points;
    }

    public void addPoints(UUID contributor, double amount) {
        points += amount;
        contributions.merge(contributor, amount, Double::sum);
    }

    public double getContribution(UUID uuid) {
        return contributions.getOrDefault(uuid, 0.0);
    }

    public void setContribution(UUID uuid, double value) {
        contributions.put(uuid, value);
    }

    public Map<UUID, Double> getContributions() {
        return Collections.unmodifiableMap(contributions);
    }

    public void resetPoints() {
        points = 0;
        contributions.clear();
    }
}
