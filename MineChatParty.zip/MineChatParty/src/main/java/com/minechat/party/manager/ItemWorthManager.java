package com.minechat.party.manager;

import com.minechat.party.MineChatParty;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.EnumMap;
import java.util.Map;

/** Knows what each sellable item is worth in party points (config.yml "sell-values"). */
public final class ItemWorthManager {

    public record SellResult(double points, int items) {
        public static final SellResult NONE = new SellResult(0, 0);
    }

    private final MineChatParty plugin;
    private final Map<Material, Double> values = new EnumMap<>(Material.class);
    private boolean ignoreCustomItems = true;

    public ItemWorthManager(MineChatParty plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        values.clear();
        ignoreCustomItems = plugin.getConfig().getBoolean("ignore-custom-items", true);

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("sell-values");
        if (section == null) {
            plugin.getLogger().warning("config.yml has no 'sell-values' section - nothing can be sold!");
            return;
        }
        for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key);
            if (material == null || material.isAir() || !material.isItem()) {
                plugin.getLogger().warning("Unknown item in sell-values: " + key);
                continue;
            }
            double value = section.getDouble(key);
            if (value > 0) {
                values.put(material, value);
            }
        }
        plugin.getLogger().info("Loaded " + values.size() + " sellable items.");
    }

    /** Total worth of a stack (per-item value x amount); 0 if not sellable. */
    public double getWorth(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return 0;
        }
        Double perItem = values.get(stack.getType());
        if (perItem == null) {
            return 0;
        }
        if (ignoreCustomItems && isCustom(stack)) {
            return 0;
        }
        return perItem * stack.getAmount();
    }

    private boolean isCustom(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        return meta != null && (meta.hasDisplayName() || meta.hasLore());
    }

    /** How much the whole inventory would give, without removing anything. */
    public SellResult previewAll(Player player) {
        double points = 0;
        int items = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            double worth = getWorth(stack);
            if (worth > 0) {
                points += worth;
                items += stack.getAmount();
            }
        }
        return new SellResult(points, items);
    }

    /** Removes every sellable item from the main inventory (hotbar + storage) and returns its value. */
    public SellResult sellAll(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack[] contents = inventory.getStorageContents();
        double points = 0;
        int items = 0;

        for (int i = 0; i < contents.length; i++) {
            ItemStack stack = contents[i];
            double worth = getWorth(stack);
            if (worth > 0) {
                points += worth;
                items += stack.getAmount();
                contents[i] = null;
            }
        }
        if (items == 0) {
            return SellResult.NONE;
        }
        inventory.setStorageContents(contents);
        return new SellResult(points, items);
    }

    /** Removes only the stack in the main hand and returns its value. */
    public SellResult sellHand(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack hand = inventory.getItemInMainHand();
        double worth = getWorth(hand);
        if (worth <= 0) {
            return SellResult.NONE;
        }
        int amount = hand.getAmount();
        inventory.setItemInMainHand(new ItemStack(Material.AIR));
        return new SellResult(worth, amount);
    }
}
