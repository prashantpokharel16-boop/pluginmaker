package com.minechat.party.manager;

import com.minechat.party.MineChatParty;
import com.minechat.party.model.Party;
import com.minechat.party.model.PartyMember;
import com.minechat.party.model.PartyRole;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** Owns all parties, their members, invites, and parties.yml. */
public final class PartyManager {

    public record Invite(UUID partyId, UUID inviter, long expiresAt) {
    }

    private final MineChatParty plugin;
    private final File file;

    private final Map<UUID, Party> parties = new LinkedHashMap<>();
    private final Map<UUID, Party> playerIndex = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();

    public PartyManager(MineChatParty plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "parties.yml");
    }

    // ---------------------------------------------------------------- storage

    public void load() {
        parties.clear();
        playerIndex.clear();
        if (!file.exists()) {
            return;
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("parties");
        if (root == null) {
            return;
        }

        for (String key : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(key);
            if (section == null) {
                continue;
            }
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue;
            }
            String name = section.getString("name");
            if (name == null) {
                continue;
            }

            Party party = new Party(id, name, section.getLong("created"));
            party.setPoints(section.getDouble("points"));

            ConfigurationSection memberSection = section.getConfigurationSection("members");
            if (memberSection != null) {
                for (String memberKey : memberSection.getKeys(false)) {
                    try {
                        UUID uuid = UUID.fromString(memberKey);
                        String memberName = memberSection.getString(memberKey + ".name", "Unknown");
                        PartyRole role = PartyRole.parse(memberSection.getString(memberKey + ".role"), PartyRole.MEMBER);
                        party.addMember(new PartyMember(uuid, memberName, role));
                    } catch (IllegalArgumentException ignored) {
                        // bad UUID, skip this entry
                    }
                }
            }
            if (party.size() == 0) {
                continue;
            }
            if (party.getLeader() == null) {
                party.getMembers().iterator().next().setRole(PartyRole.LEADER);
            }

            ConfigurationSection contributionSection = section.getConfigurationSection("contributions");
            if (contributionSection != null) {
                for (String uuidKey : contributionSection.getKeys(false)) {
                    try {
                        party.setContribution(UUID.fromString(uuidKey), contributionSection.getDouble(uuidKey));
                    } catch (IllegalArgumentException ignored) {
                        // bad UUID, skip
                    }
                }
            }

            parties.put(party.getId(), party);
            for (PartyMember member : party.getMembers()) {
                playerIndex.put(member.getUuid(), party);
            }
        }
        plugin.getLogger().info("Loaded " + parties.size() + " parties.");
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Party party : parties.values()) {
            String base = "parties." + party.getId();
            yaml.set(base + ".name", party.getName());
            yaml.set(base + ".created", party.getCreatedAt());
            yaml.set(base + ".points", party.getPoints());
            for (PartyMember member : party.getMembers()) {
                String memberBase = base + ".members." + member.getUuid();
                yaml.set(memberBase + ".name", member.getName());
                yaml.set(memberBase + ".role", member.getRole().name());
            }
            for (Map.Entry<UUID, Double> entry : party.getContributions().entrySet()) {
                yaml.set(base + ".contributions." + entry.getKey(), entry.getValue());
            }
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save parties.yml", e);
        }
    }

    // ---------------------------------------------------------------- lookups

    public Collection<Party> getParties() {
        return Collections.unmodifiableCollection(parties.values());
    }

    public Party getParty(UUID player) {
        return playerIndex.get(player);
    }

    public Party getPartyById(UUID id) {
        return parties.get(id);
    }

    public Party getPartyByName(String name) {
        for (Party party : parties.values()) {
            if (party.getName().equalsIgnoreCase(name)) {
                return party;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- changes

    public Party createParty(Player leader, String name) {
        Party party = new Party(UUID.randomUUID(), name, System.currentTimeMillis());
        party.addMember(new PartyMember(leader.getUniqueId(), leader.getName(), PartyRole.LEADER));
        parties.put(party.getId(), party);
        playerIndex.put(leader.getUniqueId(), party);
        save();
        return party;
    }

    public void addMember(Party party, Player player) {
        party.addMember(new PartyMember(player.getUniqueId(), player.getName(), PartyRole.MEMBER));
        playerIndex.put(player.getUniqueId(), party);
        save();
    }

    public void removeMember(Party party, UUID uuid) {
        party.removeMember(uuid);
        playerIndex.remove(uuid);
        save();
    }

    public void disband(Party party) {
        for (PartyMember member : party.getMembers()) {
            playerIndex.remove(member.getUuid());
        }
        parties.remove(party.getId());
        invites.values().removeIf(invite -> invite.partyId().equals(party.getId()));
        save();
    }

    public void updateName(UUID uuid, String name) {
        Party party = playerIndex.get(uuid);
        if (party == null) {
            return;
        }
        PartyMember member = party.getMember(uuid);
        if (member != null && !member.getName().equals(name)) {
            member.setName(name);
            save();
        }
    }

    public void resetAllPoints() {
        for (Party party : parties.values()) {
            party.resetPoints();
        }
        save();
    }

    public void broadcast(Party party, Component message) {
        for (PartyMember member : party.getMembers()) {
            Player online = Bukkit.getPlayer(member.getUuid());
            if (online != null) {
                online.sendMessage(message);
            }
        }
    }

    // ---------------------------------------------------------------- invites

    public Invite createInvite(Party party, UUID inviter, UUID target, long ttlMillis) {
        Invite invite = new Invite(party.getId(), inviter, System.currentTimeMillis() + ttlMillis);
        invites.put(target, invite);
        return invite;
    }

    /** Returns the target's pending invite, or null if none / expired. */
    public Invite getValidInvite(UUID target) {
        Invite invite = invites.get(target);
        if (invite == null) {
            return null;
        }
        if (System.currentTimeMillis() > invite.expiresAt()) {
            invites.remove(target);
            return null;
        }
        return invite;
    }

    public void removeInvite(UUID target) {
        invites.remove(target);
    }
}
