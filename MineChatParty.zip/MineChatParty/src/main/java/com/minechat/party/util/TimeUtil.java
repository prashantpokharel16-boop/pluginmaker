package com.minechat.party.util;

public final class TimeUtil {

    private TimeUtil() {
    }

    /** Formats milliseconds as e.g. "6d 23h 59m" or "45m 10s". */
    public static String formatDuration(long millis) {
        long totalSeconds = Math.max(0L, millis) / 1000L;
        long days = totalSeconds / 86_400L;
        long hours = (totalSeconds % 86_400L) / 3_600L;
        long minutes = (totalSeconds % 3_600L) / 60L;
        long seconds = totalSeconds % 60L;

        StringBuilder sb = new StringBuilder();
        if (days > 0) {
            sb.append(days).append("d ");
        }
        if (days > 0 || hours > 0) {
            sb.append(hours).append("h ");
        }
        sb.append(minutes).append("m");
        if (days == 0 && hours == 0) {
            sb.append(' ').append(seconds).append('s');
        }
        return sb.toString();
    }
}
