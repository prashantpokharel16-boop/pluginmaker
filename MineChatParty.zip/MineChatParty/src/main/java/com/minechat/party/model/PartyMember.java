package com.minechat.party.model;

import java.util.UUID;

public final class PartyMember {

    private final UUID uuid;
    private String name;
    private PartyRole role;

    public PartyMember(UUID uuid, String name, PartyRole role) {
        this.uuid = uuid;
        this.name = name;
        this.role = role;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PartyRole getRole() {
        return role;
    }

    public void setRole(PartyRole role) {
        this.role = role;
    }
}
