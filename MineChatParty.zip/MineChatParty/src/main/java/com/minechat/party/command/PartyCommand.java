package com.minechat.party.command;

import com.minechat.party.MineChatParty;
import com.minechat.party.manager.HallOfFameManager;
import com.minechat.party.manager.ItemWorthManager;
import com.minechat.party.manager.MessageManager;
import com.minechat.party.manager.PartyManager;
import com.minechat.party.model.Party;
import com.minechat.party.model.PartyMember;
import com.minechat.party.model.PartyRole;
import com.minechat.party.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import static com.minechat.party.manager.MessageManager.parsed;
import static com.minechat.party.manager.MessageManager.ph;
import static com.minechat.party.manager.MessageManager.points;

public final class PartyCommand implements TabExecutor {

    private static final String USE_PERMISSION = "minechat.party.use";
    private static final String ADMIN_PERMISSION = "minechat.party.admin";
    private static final Pattern NAME_PATTERN = Pattern.compile("[A-Za-z0-9_]+");

    private static final List<String> SUBCOMMANDS = List.of(
            "create", "invite", "accept", "deny", "leave", "kick", "role", "transfer",
            "disband", "info", "addpoints", "worth", "hallofframe", "help");

    private final MineChatParty plugin;
    private final PartyManager parties;
    private final HallOfFameManager hallOfFame;
    private final ItemWorthManager itemWorth;
    private final MessageManager messages;

    public PartyCommand(MineChatParty plugin, PartyManager parties, HallOfFameManager hallOfFame,
                        ItemWorthManager itemWorth, MessageManager messages) {
        this.plugin = plugin;
        this.parties = parties;
        this.hallOfFame = hallOfFame;
        this.itemWorth = itemWorth;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            messages.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            messages.sendList(sender, "help");
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> create(sender, args);
            case "invite" -> invite(sender, args);
            case "accept" -> accept(sender);
            case "deny", "decline" -> deny(sender);
            case "leave" -> leave(sender);
            case "kick" -> kick(sender, args);
            case "role" -> role(sender, args);
            case "transfer" -> transfer(sender, args);
            case "disband" -> disband(sender, args);
            case "info" -> info(sender, args);
            case "addpoints" -> addPoints(sender, args);
            case "worth" -> worth(sender);
            case "hallofframe", "hof" -> hallOfFameCommand(sender, args);
            case "reload" -> reload(sender);
            case "help" -> messages.sendList(sender, "help");
            default -> messages.send(sender, "unknown-command");
        }
        return true;
    }

    // ================================================================ party management

    private void create(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/party create <name>");
            return;
        }
        if (parties.getParty(player.getUniqueId()) != null) {
            messages.send(player, "already-in-party");
            return;
        }

        String name = args[1];
        int min = plugin.getConfig().getInt("party.name-min-length", 3);
        int max = plugin.getConfig().getInt("party.name-max-length", 16);
        if (name.length() < min || name.length() > max || !NAME_PATTERN.matcher(name).matches()) {
            messages.send(player, "invalid-name", ph("min", min), ph("max", max));
            return;
        }
        if (parties.getPartyByName(name) != null) {
            messages.send(player, "name-taken");
            return;
        }

        Party party = parties.createParty(player, name);
        messages.send(player, "party-created", ph("party", party.getName()));
    }

    private void invite(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/party invite <player>");
            return;
        }
        Party party = requireParty(player);
        if (party == null || !requireRole(player, party, "party.min-role-invite", PartyRole.TRUSTED)) {
            return;
        }

        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            messages.send(player, "player-not-found", ph("player", args[1]));
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            messages.send(player, "cannot-target-self");
            return;
        }
        if (parties.getParty(target.getUniqueId()) != null) {
            messages.send(player, "target-in-party", ph("player", target.getName()));
            return;
        }
        int maxMembers = plugin.getConfig().getInt("party.max-members", 10);
        if (party.size() >= maxMembers) {
            messages.send(player, "party-full", ph("max", maxMembers));
            return;
        }
        PartyManager.Invite existing = parties.getValidInvite(target.getUniqueId());
        if (existing != null && existing.partyId().equals(party.getId())) {
            messages.send(player, "already-invited", ph("player", target.getName()));
            return;
        }

        int expireSeconds = plugin.getConfig().getInt("party.invite-expire-seconds", 60);
        parties.createInvite(party, player.getUniqueId(), target.getUniqueId(), expireSeconds * 1000L);

        messages.send(player, "invite-sent", ph("player", target.getName()), ph("seconds", expireSeconds));
        messages.send(target, "invite-received",
                ph("player", player.getName()),
                ph("party", party.getName()),
                ph("seconds", expireSeconds));
    }

    private void accept(CommandSender sender) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (parties.getParty(player.getUniqueId()) != null) {
            messages.send(player, "already-in-party");
            return;
        }
        PartyManager.Invite invite = parties.getValidInvite(player.getUniqueId());
        if (invite == null) {
            messages.send(player, "no-invite");
            return;
        }
        Party party = parties.getPartyById(invite.partyId());
        if (party == null) {
            parties.removeInvite(player.getUniqueId());
            messages.send(player, "no-invite");
            return;
        }
        int maxMembers = plugin.getConfig().getInt("party.max-members", 10);
        if (party.size() >= maxMembers) {
            messages.send(player, "party-full", ph("max", maxMembers));
            return;
        }

        parties.removeInvite(player.getUniqueId());
        // Tell the existing members first, then add the newcomer.
        parties.broadcast(party, messages.get("member-joined", ph("player", player.getName())));
        parties.addMember(party, player);
        messages.send(player, "joined-party", ph("party", party.getName()));
    }

    private void deny(CommandSender sender) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        PartyManager.Invite invite = parties.getValidInvite(player.getUniqueId());
        if (invite == null) {
            messages.send(player, "no-invite");
            return;
        }
        parties.removeInvite(player.getUniqueId());
        messages.send(player, "invite-denied");

        Player inviter = Bukkit.getPlayer(invite.inviter());
        if (inviter != null) {
            messages.send(inviter, "invite-denied-notify", ph("player", player.getName()));
        }
    }

    private void leave(CommandSender sender) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        Party party = requireParty(player);
        if (party == null) {
            return;
        }
        PartyMember me = party.getMember(player.getUniqueId());

        if (me.getRole() == PartyRole.LEADER) {
            PartyMember successor = party.findSuccessor();
            if (successor == null) {
                // Last member: the party disappears.
                parties.disband(party);
                messages.send(player, "party-disbanded", ph("party", party.getName()));
                return;
            }
            successor.setRole(PartyRole.LEADER);
            parties.removeMember(party, player.getUniqueId());
            parties.broadcast(party, messages.get("leader-changed", ph("player", successor.getName())));
        } else {
            parties.removeMember(party, player.getUniqueId());
        }

        messages.send(player, "left-party", ph("party", party.getName()));
        parties.broadcast(party, messages.get("member-left", ph("player", player.getName())));
    }

    private void kick(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/party kick <player>");
            return;
        }
        Party party = requireParty(player);
        if (party == null || !requireRole(player, party, "party.min-role-kick", PartyRole.MOD)) {
            return;
        }

        PartyMember actor = party.getMember(player.getUniqueId());
        PartyMember target = party.getMemberByName(args[1]);
        if (target == null) {
            messages.send(player, "not-in-your-party", ph("player", args[1]));
            return;
        }
        if (target.getUuid().equals(player.getUniqueId())) {
            messages.send(player, "cannot-target-self");
            return;
        }
        if (target.getRole().ordinal() >= actor.getRole().ordinal()) {
            messages.send(player, "cannot-kick-higher");
            return;
        }

        parties.removeMember(party, target.getUuid());

        Player kicked = Bukkit.getPlayer(target.getUuid());
        if (kicked != null) {
            messages.send(kicked, "kicked", ph("party", party.getName()), ph("by", player.getName()));
        }
        parties.broadcast(party, messages.get("member-kicked",
                ph("player", target.getName()), ph("by", player.getName())));
    }

    private void role(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length < 3) {
            usage(sender, "/party role <player> <member|trusted|mod>");
            return;
        }
        Party party = requireParty(player);
        if (party == null || !requireLeader(player, party)) {
            return;
        }

        PartyMember target = party.getMemberByName(args[1]);
        if (target == null) {
            messages.send(player, "not-in-your-party", ph("player", args[1]));
            return;
        }
        if (target.getUuid().equals(player.getUniqueId())) {
            messages.send(player, "cannot-target-self");
            return;
        }
        PartyRole role = PartyRole.parse(args[2], null);
        if (role == null) {
            messages.send(player, "role-invalid");
            return;
        }
        if (role == PartyRole.LEADER) {
            messages.send(player, "use-transfer");
            return;
        }

        target.setRole(role);
        parties.save();
        parties.broadcast(party, messages.get("role-changed",
                ph("player", target.getName()), ph("role", role.getDisplayName())));
    }

    private void transfer(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        if (args.length < 2) {
            usage(sender, "/party transfer <player>");
            return;
        }
        Party party = requireParty(player);
        if (party == null || !requireLeader(player, party)) {
            return;
        }

        PartyMember target = party.getMemberByName(args[1]);
        if (target == null) {
            messages.send(player, "not-in-your-party", ph("player", args[1]));
            return;
        }
        if (target.getUuid().equals(player.getUniqueId())) {
            messages.send(player, "cannot-target-self");
            return;
        }

        target.setRole(PartyRole.LEADER);
        party.getMember(player.getUniqueId()).setRole(PartyRole.MOD);
        parties.save();
        parties.broadcast(party, messages.get("leader-transferred", ph("player", target.getName())));
    }

    private void disband(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        Party party = requireParty(player);
        if (party == null || !requireLeader(player, party)) {
            return;
        }
        if (args.length < 2 || !args[1].equalsIgnoreCase("confirm")) {
            messages.send(player, "disband-confirm");
            return;
        }

        parties.broadcast(party, messages.get("party-disbanded", ph("party", party.getName())));
        parties.disband(party);
    }

    private void info(CommandSender sender, String[] args) {
        Party party;
        if (args.length >= 2) {
            party = parties.getPartyByName(args[1]);
            if (party == null) {
                messages.send(sender, "party-not-found", ph("party", args[1]));
                return;
            }
        } else {
            Player player = asPlayer(sender);
            if (player == null) {
                return;
            }
            party = requireParty(player);
            if (party == null) {
                return;
            }
        }

        messages.send(sender, "info-header",
                ph("party", party.getName()),
                ph("size", party.size()),
                ph("max", plugin.getConfig().getInt("party.max-members", 10)),
                points("points", party.getPoints()));

        List<PartyMember> members = new ArrayList<>(party.getMembers());
        members.sort((a, b) -> Integer.compare(b.getRole().ordinal(), a.getRole().ordinal()));
        for (PartyMember member : members) {
            boolean online = Bukkit.getPlayer(member.getUuid()) != null;
            messages.send(sender, "info-member",
                    ph("player", member.getName()),
                    ph("role", member.getRole().getDisplayName()),
                    parsed("status", online ? "<green>online" : "<gray>offline"),
                    points("points", party.getContribution(member.getUuid())));
        }
    }

    // ================================================================ points

    private void addPoints(CommandSender sender, String[] args) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        Party party = requireParty(player);
        if (party == null) {
            return;
        }
        if (!hallOfFame.isActive()) {
            messages.send(player, "hof-not-active");
            return;
        }

        boolean handOnly = args.length >= 2 && args[1].equalsIgnoreCase("hand");
        ItemWorthManager.SellResult result = handOnly ? itemWorth.sellHand(player) : itemWorth.sellAll(player);
        if (result.items() == 0) {
            messages.send(player, "nothing-to-sell");
            return;
        }

        hallOfFame.addPoints(party, player, result.points());
        messages.send(player, "points-added",
                ph("items", result.items()),
                points("points", result.points()),
                points("total", party.getPoints()));
    }

    private void worth(CommandSender sender) {
        Player player = asPlayer(sender);
        if (player == null) {
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        double handWorth = itemWorth.getWorth(hand);
        if (handWorth > 0) {
            messages.send(player, "worth-hand",
                    ph("item", prettyName(hand)),
                    ph("amount", hand.getAmount()),
                    points("points", handWorth));
        } else {
            messages.send(player, "worth-hand-none");
        }

        ItemWorthManager.SellResult all = itemWorth.previewAll(player);
        messages.send(player, "worth-inventory", ph("items", all.items()), points("points", all.points()));
    }

    private String prettyName(ItemStack stack) {
        return stack.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    // ================================================================ hall of fame

    private void hallOfFameCommand(CommandSender sender, String[] args) {
        if (args.length >= 2) {
            String action = args[1].toLowerCase(Locale.ROOT);
            if (action.equals("start") || action.equals("end")) {
                if (!sender.hasPermission(ADMIN_PERMISSION)) {
                    messages.send(sender, "no-permission");
                    return;
                }
                if (action.equals("start")) {
                    if (!hallOfFame.start()) {
                        messages.send(sender, "hof-already-active");
                    }
                } else if (!hallOfFame.end(HallOfFameManager.EndReason.MANUAL)) {
                    messages.send(sender, "hof-not-active");
                }
                return;
            }
            usage(sender, "/party hallofframe [start|end]");
            return;
        }
        showLeaderboard(sender);
    }

    private void showLeaderboard(CommandSender sender) {
        if (hallOfFame.getEventNumber() == 0) {
            messages.send(sender, "hof-no-event");
            return;
        }

        if (hallOfFame.isActive()) {
            messages.send(sender, "hof-header",
                    ph("event", hallOfFame.getEventNumber()),
                    ph("time", TimeUtil.formatDuration(hallOfFame.getRemainingMillis())));
        } else {
            messages.send(sender, "hof-header-ended", ph("event", hallOfFame.getEventNumber()));
        }

        Party own = (sender instanceof Player player) ? parties.getParty(player.getUniqueId()) : null;
        List<Party> board = hallOfFame.getLeaderboard();

        if (board.isEmpty()) {
            messages.send(sender, "hof-empty");
        } else {
            int size = Math.min(Math.max(1, plugin.getConfig().getInt("hall-of-fame.display-size", 10)), board.size());
            for (int i = 0; i < size; i++) {
                Party party = board.get(i);
                boolean isOwn = own != null && own.getId().equals(party.getId());
                messages.send(sender, isOwn ? "hof-line-own" : "hof-line",
                        ph("rank", i + 1),
                        ph("party", party.getName()),
                        points("points", party.getPoints()));
            }
        }

        if (own != null && sender instanceof Player player) {
            int rank = hallOfFame.getRank(own);
            messages.send(sender, "hof-yours",
                    ph("rank", rank > 0 ? "#" + rank : "unranked"),
                    points("contribution", own.getContribution(player.getUniqueId())));
        }
    }

    private void reload(CommandSender sender) {
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            messages.send(sender, "no-permission");
            return;
        }
        plugin.reloadConfig();
        itemWorth.reload();
        messages.send(sender, "reloaded");
    }

    // ================================================================ helpers

    private Player asPlayer(CommandSender sender) {
        if (sender instanceof Player player) {
            return player;
        }
        messages.send(sender, "players-only");
        return null;
    }

    private void usage(CommandSender sender, String usage) {
        messages.send(sender, "usage", ph("usage", usage));
    }

    private Party requireParty(Player player) {
        Party party = parties.getParty(player.getUniqueId());
        if (party == null) {
            messages.send(player, "not-in-party");
        }
        return party;
    }

    private boolean requireRole(Player player, Party party, String configKey, PartyRole fallback) {
        PartyRole needed = PartyRole.parse(plugin.getConfig().getString(configKey), fallback);
        PartyMember member = party.getMember(player.getUniqueId());
        if (member == null || !member.getRole().atLeast(needed)) {
            messages.send(player, "no-rank", ph("role", needed.getDisplayName()));
            return false;
        }
        return true;
    }

    private boolean requireLeader(Player player, Party party) {
        PartyMember member = party.getMember(player.getUniqueId());
        if (member == null || member.getRole() != PartyRole.LEADER) {
            messages.send(player, "no-rank", ph("role", PartyRole.LEADER.getDisplayName()));
            return false;
        }
        return true;
    }

    // ================================================================ tab completion

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            return List.of();
        }
        boolean admin = sender.hasPermission(ADMIN_PERMISSION);

        if (args.length == 1) {
            List<String> subs = new ArrayList<>(SUBCOMMANDS);
            if (admin) {
                subs.add("reload");
            }
            return filter(subs, args[0]);
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        Party own = (sender instanceof Player player) ? parties.getParty(player.getUniqueId()) : null;

        if (args.length == 2) {
            switch (sub) {
                case "invite":
                    return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
                case "kick":
                case "transfer":
                case "role":
                    if (own == null) {
                        return List.of();
                    }
                    return filter(own.getMembers().stream().map(PartyMember::getName).toList(), args[1]);
                case "info":
                    return filter(parties.getParties().stream().map(Party::getName).toList(), args[1]);
                case "addpoints":
                    return filter(List.of("hand"), args[1]);
                case "disband":
                    return filter(List.of("confirm"), args[1]);
                case "hallofframe":
                case "hof":
                    return admin ? filter(List.of("start", "end"), args[1]) : List.of();
                default:
                    return List.of();
            }
        }

        if (args.length == 3 && sub.equals("role")) {
            return filter(List.of("member", "trusted", "mod"), args[2]);
        }
        return List.of();
    }

    private static List<String> filter(Collection<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(lower))
                .sorted()
                .toList();
    }
}
