package com.minechat.party.model;

import java.util.Locale;

/** Ranks, lowest to highest. */
public enum PartyRole {
    MEMBER("Member"),
    TRUSTED("Trusted"),
    MOD("Mod"),
    LEADER("Leader");

    private final String displayName;

    PartyRole(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean atLeast(PartyRole other) {
        return this.ordinal() >= other.ordinal();
    }

    public static PartyRole parse(String input, PartyRole fallback) {
        if (input == null) {
            return fallback;
        }
        try {
            return valueOf(input.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
