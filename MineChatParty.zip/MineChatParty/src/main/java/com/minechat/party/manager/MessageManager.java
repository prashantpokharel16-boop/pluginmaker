package com.minechat.party.manager;

import com.minechat.party.MineChatParty;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Reads messages from config.yml and renders them with MiniMessage (bundled with Paper). */
public final class MessageManager {

    private static final MiniMessage MINI = MiniMessage.miniMessage();

    private final MineChatParty plugin;

    public MessageManager(MineChatParty plugin) {
        this.plugin = plugin;
    }

    public Component get(String key, TagResolver... extra) {
        String raw = plugin.getConfig().getString("messages." + key);
        if (raw == null) {
            raw = "<red>Missing message in config.yml: " + key;
        }
        return render(raw, extra);
    }

    private Component render(String raw, TagResolver... extra) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        TagResolver resolver = TagResolver.builder()
                .resolver(Placeholder.parsed("prefix", prefix))
                .resolvers(extra)
                .build();
        return MINI.deserialize(raw, resolver);
    }

    public void send(CommandSender target, String key, TagResolver... extra) {
        target.sendMessage(get(key, extra));
    }

    /** Sends every line of a message list (e.g. "help"). */
    public void sendList(CommandSender target, String key, TagResolver... extra) {
        for (String line : plugin.getConfig().getStringList("messages." + key)) {
            target.sendMessage(render(line, extra));
        }
    }

    public void broadcast(String key, TagResolver... extra) {
        Bukkit.getServer().broadcast(get(key, extra));
    }

    // ---- placeholder helpers ----

    /** Plain-text placeholder (safe for player-provided text). */
    public static TagResolver ph(String name, Object value) {
        return Placeholder.unparsed(name, String.valueOf(value));
    }

    /** Placeholder whose value may contain MiniMessage tags. */
    public static TagResolver parsed(String name, String value) {
        return Placeholder.parsed(name, value);
    }

    public static TagResolver points(String name, double value) {
        return Placeholder.unparsed(name, formatPoints(value));
    }

    public static String formatPoints(double value) {
        return new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US)).format(value);
    }
}
