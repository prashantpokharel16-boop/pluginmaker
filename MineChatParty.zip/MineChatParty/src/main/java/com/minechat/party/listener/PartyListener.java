package com.minechat.party.listener;

import com.minechat.party.manager.PartyManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class PartyListener implements Listener {

    private final PartyManager parties;

    public PartyListener(PartyManager parties) {
        this.parties = parties;
    }

    /** Keeps the stored member names up to date when players change their username. */
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        parties.updateName(event.getPlayer().getUniqueId(), event.getPlayer().getName());
    }
}
