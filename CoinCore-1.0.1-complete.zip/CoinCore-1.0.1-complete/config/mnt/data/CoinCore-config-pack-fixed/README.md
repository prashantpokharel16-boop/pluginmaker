# CoinCore — MineChat SMP

A GUI-first **Coins** progression/economy plugin for Paper 26.1.2.

## Target
- Paper 26.1.2 build 74
- Java 25 runtime recommended by Paper 26.1.x
- Works with Vault + a Vault economy provider for exchange features
- Soft-integrates with CoreCrates and LuckPerms through configurable server commands

Paper 26.1.x uses Java 25 at runtime. The source can be compiled with a newer JDK or a compatible toolchain; the Maven project currently targets Java 21 bytecode for broad compatibility.

## Player commands
- `/coins` — open the main CoinCore dashboard
- `/keys` — buy Rare / Money / Daily keys
- `/coinshop` — open the Coin Shop

## Coin earning
- +1 coin every minute online (configurable)
- +1 coin per block broken (configurable)
- +1 coin per block placed (configurable)
- A per-minute block reward cap prevents accidental runaway automation; set to `0` only if you deliberately want no cap and update the listener if you need unlimited farming.

## Main GUI
- Balance display
- Key Shop
- Coin Shop
- Coins ↔ Vault exchange
- Pets
- Earning guide

## Default key prices
- Daily: 10 coins
- Rare: 33 coins
- Money: 40 coins

The exact CoreCrates crate IDs are configurable under `corecrates.*-crate`.

## Default ranks
- VIP: 10,000 coins → `lp user {player} parent add vip`
- MVP: 20,000 coins → `lp user {player} parent add mvp`

Change these commands if your LuckPerms groups use different names.

## Included shop
Max-enchanted netherite combat/tool gear, Totems of Undying, enchanted golden apples, pearls, XP bottles, Beacon, Elytra, Mending book, plus VIP/MVP rank purchases.

## Pets
- Coin Wolf
- Coin Cat
- Coin Allay

Pets follow the owner while online and are removed when the player leaves. This intentionally avoids leaving hundreds of pet entities around the server.

## Admin commands
Permission: `coincore.admin` (default OP)

- `/coinadmin give <player> <amount>`
- `/coinadmin take <player> <amount>`
- `/coinadmin set <player> <amount>`
- `/coinadmin balance <player>`
- `/coinadmin reload`
- `/coins admin ...` also works

## Installation
1. Build the Maven project with JDK 21+.
2. Put `CoinCore-1.0.0.jar` into `plugins/`.
3. Install Vault and a Vault-compatible economy provider if you want exchange support.
4. Install CoreCrates if you want the three key buttons to actually grant keys.
5. Install LuckPerms if you want VIP/MVP purchase commands to change groups.
6. Start Paper once, then edit `plugins/CoinCore/config.yml`.

## Important
This package contains the complete source project and configuration. The current execution environment did not have Maven installed and could not resolve external downloads, so the JAR was **not falsely represented as compiled**. Build it on your PC/VM with Maven.
