package com.minechat.coincore;

import com.minechat.coincore.command.CoinCommand;
import com.minechat.coincore.data.CoinManager;
import com.minechat.coincore.gui.GuiListener;
import com.minechat.coincore.listener.CoinListener;
import com.minechat.coincore.pet.PetManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class CoinCore extends JavaPlugin {
    private CoinManager coins;
    private PetManager pets;

    @Override public void onEnable() {
        saveDefaultConfig();
        coins = new CoinManager(this);
        pets = new PetManager(this);
        coins.load();
        getServer().getPluginManager().registerEvents(new CoinListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(pets, this);
        CoinCommand command = new CoinCommand(this);
        getCommand("coins").setExecutor(command); getCommand("coins").setTabCompleter(command);
        getCommand("keys").setExecutor(command); getCommand("coinshop").setExecutor(command);
        getCommand("coinadmin").setExecutor(command); getCommand("coinadmin").setTabCompleter(command);
        getServer().getScheduler().runTaskTimer(this, () -> {
            for (var p : getServer().getOnlinePlayers()) coins.add(p.getUniqueId(), getConfig().getDouble("settings.coins-per-minute", 1));
        }, 1200L, 1200L);
        getServer().getScheduler().runTaskTimer(this, coins::save, 20L * getConfig().getLong("settings.autosave-seconds", 30), 20L * getConfig().getLong("settings.autosave-seconds", 30));
        getLogger().info("CoinCore enabled for Paper 26.1.2 — currency: Coins");
    }
    @Override public void onDisable() { if (coins != null) coins.save(); if (pets != null) pets.removeAll(); }
    public CoinManager coins() { return coins; }
    public PetManager pets() { return pets; }
}
