package com.minechat.coincore.data;

import com.minechat.coincore.CoinCore;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class CoinManager {
    private final CoinCore plugin; private final Map<UUID, Double> balances = new HashMap<>(); private File file; private YamlConfiguration data;
    public CoinManager(CoinCore plugin){this.plugin=plugin;}
    public void load(){ file=new File(plugin.getDataFolder(),"balances.yml"); if(!file.exists()) try{file.getParentFile().mkdirs();file.createNewFile();}catch(IOException ignored){} data=YamlConfiguration.loadConfiguration(file); for(String k:data.getKeys(false)) try{balances.put(UUID.fromString(k),data.getDouble(k));}catch(Exception ignored){} }
    public synchronized void save(){ if(data==null)return; for(var e:balances.entrySet())data.set(e.getKey().toString(),e.getValue()); try{data.save(file);}catch(IOException e){plugin.getLogger().warning("Could not save balances: "+e.getMessage());} }
    public double get(UUID u){return balances.getOrDefault(u, plugin.getConfig().getDouble("settings.starting-coins",0));}
    public void set(UUID u,double amount){balances.put(u,Math.max(0,amount));}
    public void add(UUID u,double amount){set(u,get(u)+amount);}
    public boolean take(UUID u,double amount){if(get(u)+1e-9<amount)return false;set(u,get(u)-amount);return true;}
}
