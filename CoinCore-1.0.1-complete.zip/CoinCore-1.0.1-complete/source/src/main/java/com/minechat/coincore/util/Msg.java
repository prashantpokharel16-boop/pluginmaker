package com.minechat.coincore.util;
import org.bukkit.ChatColor; import org.bukkit.command.CommandSender;
public final class Msg { public static String c(String s){return ChatColor.translateAlternateColorCodes('&',s);} public static void send(CommandSender s,String m){s.sendMessage(c(m));} }
