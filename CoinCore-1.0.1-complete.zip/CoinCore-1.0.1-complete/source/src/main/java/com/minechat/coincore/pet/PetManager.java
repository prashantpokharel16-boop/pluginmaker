package com.minechat.coincore.pet;
import com.minechat.coincore.CoinCore; import com.minechat.coincore.util.Msg; import org.bukkit.*; import org.bukkit.entity.*; import org.bukkit.event.*; import org.bukkit.event.player.PlayerQuitEvent; import org.bukkit.scheduler.BukkitTask; import java.util.*;
public class PetManager implements Listener {private final CoinCore p;private final Map<UUID,Entity> pets=new HashMap<>();private final BukkitTask task;
 public PetManager(CoinCore p){this.p=p;task=p.getServer().getScheduler().runTaskTimer(p,()->{for(var e:pets.entrySet()){Player pl=Bukkit.getPlayer(e.getKey());Entity pet=e.getValue();if(pl==null||!pet.isValid())continue;if(pet.getLocation().distanceSquared(pl.getLocation())>64){Location l=pl.getLocation().clone().add(pl.getLocation().getDirection().normalize().multiply(-2));l.setY(pl.getLocation().getY());pet.teleport(l);} }},10L,10L);}
 public void summon(Player pl,String key){remove(pl.getUniqueId());String entity=p.getConfig().getString("pets."+key+".entity","WOLF");EntityType t;try{t=EntityType.valueOf(entity);}catch(Exception ex){Msg.send(pl,"&cPet type unavailable.");return;}Entity e=pl.getWorld().spawnEntity(pl.getLocation().add(1,0,1),t);e.customName(net.kyori.adventure.text.Component.text(com.minechat.coincore.util.Items.strip(p.getConfig().getString("pets."+key+".name",key))));e.setCustomNameVisible(true);if(e instanceof Tameable tame)tame.setOwner(pl);pets.put(pl.getUniqueId(),e);Msg.send(pl,"&aYour pet has joined you! It will follow you until you leave.");}
 public void remove(UUID u){Entity e=pets.remove(u);if(e!=null)e.remove();}
 @EventHandler public void quit(PlayerQuitEvent e){remove(e.getPlayer().getUniqueId());}
 public void removeAll(){for(Entity e:pets.values())e.remove();pets.clear();task.cancel();}
}
