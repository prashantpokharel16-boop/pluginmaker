package com.minechat.coincore.util;
import net.kyori.adventure.text.Component; import net.kyori.adventure.text.format.NamedTextColor; import org.bukkit.Material; import org.bukkit.enchantments.Enchantment; import org.bukkit.inventory.ItemStack; import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;
public final class Items {
 public static ItemStack item(Material m,int amount,String name,List<String> lore){ItemStack i=new ItemStack(m,amount);ItemMeta meta=i.getItemMeta();meta.displayName(Component.text(strip(name),NamedTextColor.WHITE)); if(lore!=null)meta.lore(lore.stream().map(x->Component.text(strip(x))).toList());i.setItemMeta(meta);return i;}
 public static void ench(ItemStack i,String spec){try{String[] p=spec.split(":");Enchantment e=Enchantment.getByName(p[0]);if(e!=null)i.addUnsafeEnchantment(e,Integer.parseInt(p[1]));}catch(Exception ignored){}}
 public static String strip(String s){return s.replaceAll("&[0-9a-fk-or]","" );}
}
