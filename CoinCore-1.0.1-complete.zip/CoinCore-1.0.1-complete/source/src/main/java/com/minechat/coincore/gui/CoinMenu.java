package com.minechat.coincore.gui;
import com.minechat.coincore.CoinCore; import com.minechat.coincore.util.Items; import org.bukkit.*; import org.bukkit.inventory.*; import java.util.*;
public final class CoinMenu {
 public enum Type { MAIN, KEYS, SHOP, CONVERT, PETS }
 public static Inventory open(CoinCore p, Player player, Type type){
  Inventory inv=Bukkit.createInventory(new Holder(type),54, title(type));
  fill(inv, Material.BLACK_STAINED_GLASS_PANE);
  if(type==Type.MAIN) main(p,player,inv); if(type==Type.KEYS) keys(p,inv); if(type==Type.SHOP) shop(p,inv); if(type==Type.CONVERT) convert(p,inv); if(type==Type.PETS) pets(p,inv);
  return inv;
 }
 static String title(Type t){return switch(t){case MAIN->"✦ CoinCore • Coins";case KEYS->"🔑 CoinCore • Keys";case SHOP->"✦ CoinCore • Coin Shop";case CONVERT->"⇄ CoinCore • Exchange";case PETS->"🐾 CoinCore • Pets";};}
 static void fill(Inventory i,Material m){for(int x=0;x<i.getSize();x++)i.setItem(x,Items.item(m,1," ",List.of()));}
 static void main(CoinCore p,Player pl,Inventory i){
  i.setItem(4,Items.item(Material.SUNFLOWER,1,"&6✦ COINS",List.of("&7Your balance: &e"+fmt(p.coins().get(pl.getUniqueId())),"&7Earn +1 every minute","&7Earn +1 per block action")));
  i.setItem(20,Items.item(Material.TRIPWIRE_HOOK,1,"&b🔑 KEY SHOP",List.of("&7Buy Rare, Money and Daily keys","&eClick to open")));
  i.setItem(22,Items.item(Material.DIAMOND,1,"&d✦ COIN SHOP",List.of("&7Combat gear, totems, utilities","&7and special items","&eClick to open")));
  i.setItem(24,Items.item(Material.EMERALD,1,"&a⇄ EXCHANGE",List.of("&7Convert Coins ↔ Vault balance","&7Requires Vault + economy plugin","&eClick to open")));
  i.setItem(30,Items.item(Material.BONE,1,"&f🐾 PETS",List.of("&7Collect a pet that follows you","&eClick to open")));
  i.setItem(32,Items.item(Material.NETHER_STAR,1,"&e✦ RANKS",List.of("&7VIP — 10,000 coins","&7MVP — 20,000 coins","&7Click Coin Shop to purchase")));
  i.setItem(40,Items.item(Material.BOOK,1,"&fHOW TO EARN",List.of("&71. Stay online: +1/min","&72. Break blocks: +1/block","&73. Place blocks: +1/block","&7Use /coins anytime")));
 }
 static void keys(CoinCore p,Inventory i){int[] slots={20,22,24}; String[] names={"rare","money","daily"}; Material[] mats={Material.PURPLE_DYE,Material.GOLD_INGOT,Material.CLOCK}; for(int x=0;x<3;x++){double c=p.getConfig().getDouble("keys."+names[x]);i.setItem(slots[x],Items.item(mats[x],1,"&d🔑 "+cap(names[x])+" Key",List.of("&7Cost: &e"+fmt(c)+" coins","&7Uses your CoreCrates crate: &f"+p.getConfig().getString("corecrates."+names[x]+"-crate",names[x]),"","&aClick to buy 1")));} i.setItem(49,Items.item(Material.BARRIER,1,"&cBack",List.of()));}
 static void shop(CoinCore p,Inventory i){var sec=p.getConfig().getConfigurationSection("shop.items");int slot=10;if(sec!=null)for(String k:sec.getKeys(false)){if(slot>=44)break;String path="shop.items."+k;Material m=mat(p.getConfig().getString(path+".material"));if(m==null)continue;double c=p.getConfig().getDouble(path+".price");String n=p.getConfig().getString(path+".name",k);List<String> l=p.getConfig().getStringList(path+".lore");ArrayList<String> lore=new ArrayList<>(l);lore.add(0,"&7Price: &e"+fmt(c)+" coins");i.setItem(slot++,Items.item(m,p.getConfig().getInt(path+".amount",1),n,lore));if(slot%9==8)slot+=2;} i.setItem(45,Items.item(Material.GOLD_BLOCK,1,"&6VIP Rank",List.of("&7Cost: &e10,000 coins","&eClick to purchase")));i.setItem(46,Items.item(Material.DIAMOND_BLOCK,1,"&bMVP Rank",List.of("&7Cost: &e20,000 coins","&eClick to purchase")));i.setItem(49,Items.item(Material.BARRIER,1,"&cBack",List.of()));}
 static void convert(CoinCore p,Inventory i){double r=p.getConfig().getDouble("settings.coins-per-vault",1);double v=p.getConfig().getDouble("settings.vault-per-coin",1);i.setItem(20,Items.item(Material.GOLD_INGOT,1,"&6Coins → Vault",List.of("&7Rate: &e1 coin = "+v+" Vault","&7Click: 100 coins","&eLeft click = 100","&eRight click = 1000")));i.setItem(24,Items.item(Material.EMERALD,1,"&aVault → Coins",List.of("&7Rate: &e1 Vault = "+r+" coins","&7Click: 100 Vault","&eLeft click = 100","&eRight click = 1000")));i.setItem(49,Items.item(Material.BARRIER,1,"&cBack",List.of()));}
 static void pets(CoinCore p,Inventory i){var sec=p.getConfig().getConfigurationSection("pets");int slot=20;if(sec!=null)for(String k:sec.getKeys(false)){String path="pets."+k;Material m=mat(p.getConfig().getString(path+".material"));double c=p.getConfig().getDouble(path+".price");i.setItem(slot++,Items.item(m,1,p.getConfig().getString(path+".name",k),List.of("&7Price: &e"+fmt(c)+" coins","&7This pet follows you","&eClick to summon")));}i.setItem(49,Items.item(Material.BARRIER,1,"&cBack",List.of()));}
 static Material mat(String s){try{return Material.valueOf(s.toUpperCase(Locale.ROOT));}catch(Exception e){return null;}} public static String fmt(double n){return n%1==0?String.format("%.0f",n):String.format("%.2f",n);} static String cap(String s){return s.substring(0,1).toUpperCase()+s.substring(1);}
 public static class Holder implements InventoryHolder {private final Type type; public Holder(Type t){type=t;}public Type type(){return type;}public Inventory getInventory(){return null;}}
}
