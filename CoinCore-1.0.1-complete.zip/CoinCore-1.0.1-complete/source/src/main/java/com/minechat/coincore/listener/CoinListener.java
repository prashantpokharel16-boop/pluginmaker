package com.minechat.coincore.listener;
import com.minechat.coincore.CoinCore; import org.bukkit.entity.Player; import org.bukkit.event.*; import org.bukkit.event.block.BlockBreakEvent; import org.bukkit.event.block.BlockPlaceEvent; import org.bukkit.event.player.PlayerJoinEvent; import org.bukkit.event.player.PlayerQuitEvent; import java.util.*;
public class CoinListener implements Listener {
 private final CoinCore p; private final Map<UUID,Long> window=new HashMap<>(); private final Map<UUID,Integer> count=new HashMap<>(); public CoinListener(CoinCore p){this.p=p;}
 private void earn(Player pl,double amount){if(amount<=0)return;long now=System.currentTimeMillis();UUID u=pl.getUniqueId();long start=window.getOrDefault(u,now);if(now-start>=60000){window.put(u,now);count.put(u,0);}int used=count.getOrDefault(u,0);int max=p.getConfig().getInt("settings.max-block-reward-per-minute",120);if(used>=max)return;int give=(int)Math.min(amount,max-used);count.put(u,used+give);p.coins().add(u,give);if(p.getConfig().getBoolean("settings.actionbar-balance",true))pl.sendActionBar("§6+"+give+" Coin"+(give==1?"":"s")+" §8• §e"+String.format("%.0f",p.coins().get(u))+" Coins");}
 @EventHandler public void breakBlock(BlockBreakEvent e){if(!e.isCancelled())earn(e.getPlayer(),p.getConfig().getDouble("settings.coins-per-block-break",1));}
 @EventHandler public void placeBlock(BlockPlaceEvent e){if(!e.isCancelled())earn(e.getPlayer(),p.getConfig().getDouble("settings.coins-per-block-place",1));}
 @EventHandler public void join(PlayerJoinEvent e){p.coins().get(e.getPlayer().getUniqueId());}
 @EventHandler public void quit(PlayerQuitEvent e){window.remove(e.getPlayer().getUniqueId());count.remove(e.getPlayer().getUniqueId());}
}
